package com.example.assignmentofstafftable;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class Tablepage extends AppCompatActivity {
    private ArrayList<EmployeeModel> employees;

    private RecyclerView rvEmployees;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tablepage);
        Button bnsignout = findViewById(R.id.bn_signout);
        Button bnadd = findViewById(R.id.bn_add);
        Button bndelete = findViewById(R.id.bn_delete);

        rvEmployees = (RecyclerView) findViewById(R.id.rvEmployees);

        employees = new ArrayList<>();
        getData();


        rvEmployees.setLayoutManager(new LinearLayoutManager(this));
        rvEmployees.setAdapter(new EmpAdapter(employees));




        bnsignout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                Toast.makeText(Tablepage.this, "Sign Out!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Tablepage.this, LoginPage.class);
                startActivity(intent);
                finish();
            }
        });
    }




    protected void getData() {

        RequestQueue queue = Volley.newRequestQueue(Tablepage.this);
        String url = "http://web.socem.plymouth.ac.uk/COMP2000/api/employees/";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject obj = response.getJSONObject(i);
                                EmployeeModel empModel = new EmployeeModel(
                                        obj.getInt("id"),
                                        obj.getString("surname"),
                                        obj.getString("forename")

                                );
                                employees.add(empModel);
                            }

                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error
                        Log.e("ERROR", error.getMessage());
                    }


                });


        queue.add(jsonArrayRequest);
    }

    }



