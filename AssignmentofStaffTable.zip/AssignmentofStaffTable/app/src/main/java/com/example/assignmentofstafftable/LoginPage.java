package com.example.assignmentofstafftable;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        EditText Username=findViewById(R.id.tx_loginun);
        EditText Password=findViewById(R.id.tx_loginpw);
        Button bnsignin=findViewById(R.id.bu_loginsi);
        Button bnsignup=findViewById(R.id.signuppage);
        sqldb db = new sqldb(this);



        bnsignup.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent intent = new Intent(LoginPage.this, MainActivity.class);
                startActivity(intent);
                finish();

            }
        });


        bnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = Username.getText().toString();
                String pass = Password.getText().toString();




                if (user.equals("") || pass.equals(""))
                    Toast.makeText(LoginPage.this, "Please fill in your Username and Password !!!", Toast.LENGTH_SHORT).show();
                else {

                    Boolean checkuserpass = db.checkusernamepassword(user, pass);

                    if (checkuserpass == true) {
                        Toast.makeText(LoginPage.this, "Login successfully!!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginPage.this, RequestPage.class);
                        startActivity(intent);




                    }else {
                        Toast.makeText(LoginPage.this, "Your Account is not Exist", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginPage.this, LoginPage.class);
                        startActivity(intent);
                        finish();
                    }

                    if (user.equals("ad") && pass.equals("123@lvmh")) {

                        Intent intent = new Intent(LoginPage.this, Tablepage.class);
                        startActivity(intent);



                    }
                    }
                }


        });


    }
}