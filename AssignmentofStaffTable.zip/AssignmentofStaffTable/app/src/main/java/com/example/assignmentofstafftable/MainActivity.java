package com.example.assignmentofstafftable;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText L_Username=findViewById(R.id.tx_username);
        EditText L_Password=findViewById(R.id.tx_password);
        EditText L_Repassword=findViewById(R.id.tx_repw);
        Button B_Signup=findViewById(R.id.bn_signup);
        Button B_Signin=findViewById(R.id.bn_signin);
        sqldb db = new sqldb(this);




        B_Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = L_Username.getText().toString();
                String pass = L_Password.getText().toString();
                String repass = L_Repassword.getText().toString();

                if (user.equals("") || pass.equals("") || repass.equals(""))
                    Toast.makeText(MainActivity.this, "Please Fill all in!!!", Toast.LENGTH_SHORT).show();
                else{
                    if (pass.equals(repass)) {
                        Boolean checkuser = db.checkusername(user);
                        if (checkuser == false) {
                            Boolean insert = db.insertData(user, pass);
                            if (insert == true) {
                                Toast.makeText(MainActivity.this, "Successfully Registered!!!!", Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                                startActivity(intent);


                            } else {
                                Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "User Existed!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Please type the password again!!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        B_Signin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this,LoginPage.class);
                startActivity(intent);


            }
        });
    }
}