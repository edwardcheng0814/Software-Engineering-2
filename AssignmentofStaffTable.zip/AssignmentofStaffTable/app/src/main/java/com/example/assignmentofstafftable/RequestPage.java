package com.example.assignmentofstafftable;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RequestPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_page);


        Button bnsubmit = findViewById(R.id.bn_submit);
        Button bnsigno = findViewById(R.id.bnsigno);


        bnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(RequestPage.this, "Sumbit Success !!!", Toast.LENGTH_SHORT).show();
            }


        });

        bnsigno.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                Toast.makeText(RequestPage.this, "Sign Out!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RequestPage.this, LoginPage.class);
                startActivity(intent);
                finish();
            }
        });
    }

    }
