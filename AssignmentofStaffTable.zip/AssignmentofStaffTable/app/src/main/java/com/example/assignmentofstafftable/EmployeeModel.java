package com.example.assignmentofstafftable;

public class EmployeeModel {
    private int id;
    private String surname;
    private String forename;

    public EmployeeModel(int id, String surname, String forename) {
        this.id = id;
        this.surname = surname;
        this.forename = forename;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getForename() {
        return forename;
    }

    public void setForename(String forename) {
        this.forename = forename;
    }

    @Override
    public String toString() {
        return String.format("id: %d | surname: %s | forename: %s", this.getId(), this.getSurname(), this.getForename());
    }
}
