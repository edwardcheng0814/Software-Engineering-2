package com.example.assignmentofstafftable;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EmpAdapter extends RecyclerView.Adapter<EmpAdapter.EmpHolder>{

    private ArrayList<EmployeeModel> myEmpModel;

    public EmpAdapter(ArrayList<EmployeeModel> myEmpModel) {
        this.myEmpModel = myEmpModel;
    }

    @NonNull
    @Override
    public EmpHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_emp_adapter, parent, false);
        return new EmpHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EmpHolder holder, int position) {
    if(myEmpModel != null && myEmpModel.size()>0) {
        EmployeeModel empModel = myEmpModel.get(position);

        // Set item views based on your views and data model
        holder.tv_empId.setText(empModel.getId());
        holder.tv_surname.setText(empModel.getId());
        holder.tv_forename.setText(empModel.getId());
    }else{
        return;
    }
    }

    @Override
    public int getItemCount() {
        return myEmpModel.size();
    }


    public static class EmpHolder extends RecyclerView.ViewHolder {

        public TextView tv_empId, tv_surname, tv_forename;

        public EmpHolder(View view) {
            super(view);
            tv_empId = view.findViewById(R.id.tv_empId);
            tv_surname = view.findViewById(R.id.tv_surname);
            tv_forename = view.findViewById(R.id.tv_forename);
        }
    }
}
